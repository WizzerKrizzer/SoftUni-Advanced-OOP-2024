﻿namespace MailClient
{
    public class MailBox
    {
        public MailBox(int capacity)
        {
            Capacity = capacity;
            Inbox = new List<Mail>();
            Archive = new List<Mail>();
        }

        public int Capacity { get; }
        public List<Mail> Inbox { get; }
        public List<Mail> Archive { get; }

        public void IncomingMail(Mail mail)
        {
            if (Inbox.Count < Capacity)
            {
                Inbox.Add(mail);
            }
            else
            {
                Console.WriteLine("Inbox is full. Cannot add more mails.");
            }
        }

        public bool DeleteMail(string sender)
        {
            Mail mailToRemove = Inbox.FirstOrDefault(mail => mail.Sender == sender);

            if (mailToRemove != null)
            {
                Inbox.Remove(mailToRemove);
                return true;
            }

            return false;
        }

        public int ArchiveInboxMessages()
        {
            Archive.AddRange(Inbox);
            int countMoved = Inbox.Count;
            Inbox.Clear();
            return countMoved;
        }

        public string GetLongestMessage()
        {
            Mail longestMail = Inbox.Concat(Archive)
                                    .OrderByDescending(mail => mail.Body.Length)
                                    .FirstOrDefault();

            return longestMail?.ToString();
        }

        public string InboxView()
        {
            string inboxView = "Inbox:\n";

            foreach (var mail in Inbox)
            {
                inboxView += mail + "\n";
            }

            return inboxView.Trim();
        }
    }
}
