﻿namespace MailClient
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // Example usage:
            MailBox mailBox = new MailBox(2);

            // Incoming mails
            mailBox.IncomingMail(new Mail("John", "Alice", "Hello, how are you?"));
            mailBox.IncomingMail(new Mail("Alice", "John", "I'm fine, thank you!"));

            // View Inbox
            Console.WriteLine(mailBox.InboxView());

            // Delete mail from Inbox
            bool deleted = mailBox.DeleteMail("John");
            Console.WriteLine($"Mail from John deleted: {deleted}");

            // Archive Inbox messages
            int countMoved = mailBox.ArchiveInboxMessages();
            Console.WriteLine($"Moved {countMoved} messages to Archive");

            // View Inbox after archiving
            Console.WriteLine(mailBox.InboxView());

            // Get the longest message
            string longestMessage = mailBox.GetLongestMessage();
            Console.WriteLine($"Longest Message:\n{longestMessage}");
        }
    }
}