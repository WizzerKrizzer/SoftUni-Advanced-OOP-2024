﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Coffee : HotBeverage
    {
        public Coffee(string name, decimal price, double milliliters)
            : base(name, price, milliliters)
        {

        }
        public double CoffeeMilliliters = 50;
        public double CoffeePrice = 3.10;
        public double Caffeine { get; set; }
    }
}
