﻿namespace ShoppingSpree
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<string> People = Console.ReadLine().Split("=").ToList();
            List<string> Products = Console.ReadLine().Split("=").ToList();

        }
    }
}