﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingSpree
{
    public class Person
    {
        private string name;
        private double money;
        private List<Product> bagOfProducts;

        public Person(string name, double money)
        {
            Name = name;
            Money = money;
        }

        public string Name
        {
            get 
            { 
                return name; 
            }
            set 
            { 
                if(string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Name cannot be empty");
                }
                name = value; 
            }
        }
        public double Money
        {
            get
            {
                return money;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentNullException("Money cannot be negative");
                }
                money = value;
            }
        }
        public List<Product> BagOfProducts
        {
            get
            {
                return bagOfProducts;
            }
            set
            {
                bagOfProducts = value;
            }
        }

        public void AddToBag()
        {
            
        }
    }
}
