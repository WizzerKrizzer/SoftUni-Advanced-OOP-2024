﻿using InfluencerManagerApp.Core.Contracts;
using InfluencerManagerApp.Models;
using InfluencerManagerApp.Models.Contracts;
using InfluencerManagerApp.Repositories;
using InfluencerManagerApp.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfluencerManagerApp.Core
{
    public class Controller : IController
    {
        private IRepository<IInfluencer> influencers;
        private IRepository<ICampaign> campaigns;
        private readonly InfluencerRepository influencerRepository;
        private readonly CampaignRepository campaignRepository;


        public Controller()
        {
            influencers = new InfluencerRepository();
            campaigns = new CampaignRepository();
            influencerRepository = new InfluencerRepository();
            campaignRepository = new CampaignRepository();
        }



        public string ApplicationReport()
        {
            var orderedInfluencers = influencerRepository.Models
                .OrderByDescending(i => i.Income)
                .ThenByDescending(i => i.Followers);

            StringBuilder reportBuilder = new StringBuilder();
            foreach (var influencer in orderedInfluencers)
            {
                reportBuilder.AppendLine(influencer.ToString());
                reportBuilder.AppendLine("Active Campaigns:");

                var activeCampaigns = influencer.Participations.OrderBy(c => c);
                foreach (var campaign in activeCampaigns)
                {
                    reportBuilder.AppendLine($"--{campaign}");
                }
            }

            return reportBuilder.ToString();
        }



        public string AttractInfluencer(string brand, string username)
        {
            var influencer = influencerRepository.FindByName(username);
            if (influencer == null)
            {
                return $"{nameof(InfluencerRepository)} has no {username} registered in the application.";
            }

            var campaign = campaignRepository.FindByName(brand);
            if (campaign == null)
            {
                return $"There is no campaign from {brand} in the application.";
            }

            if (campaign.Contributors.Contains(username))
            {
                return $"{username} is already engaged for the {brand} campaign.";
            }

            if ((campaign.GetType() == typeof(ProductCampaign) && !(influencer is BusinessInfluencer || influencer is FashionInfluencer)) ||
                (campaign.GetType() == typeof(ServiceCampaign) && !(influencer is BusinessInfluencer || influencer is BloggerInfluencer)))
            {
                return $"{username} is not eligible for the {brand} campaign.";
            }

            var campaignPrice = CalculateCampaignPrice(campaign, influencer);
            if (campaignPrice > campaign.Budget)
            {
                return $"The budget for {brand} is insufficient to engage {username}.";
            }

            // Flag to track successful attraction
            bool attractedSuccessfully = false;

            // Attempt to attract the influencer to the campaign
            try
            {
                influencer.EarnFee(campaignPrice);
                influencer.EnrollCampaign(brand);
                campaign.Gain(-campaignPrice);
                campaign.Engage(influencer);
                attractedSuccessfully = true;
            }
            catch (Exception ex)
            {
                // Log or handle the exception, if needed
                // You can also return a specific error message here if required
            }

            // Return appropriate message based on attraction success
            return 
                $"{username} has been successfully attracted to the {brand} campaign.";
        }




        public string BeginCampaign(string typeName, string brand)
        {
            switch (typeName)
            {
                case "ProductCampaign":
                    {
                        var campaign = new ProductCampaign(brand);
                        return AddCampaignToRepository(campaign);
                    }
                case "ServiceCampaign":
                    {
                        var campaign = new ServiceCampaign(brand);
                        return AddCampaignToRepository(campaign);
                    }
                default:
                    return $"{typeName} is not a valid campaign in the application.";
            }
        }



        public string CloseCampaign(string brand)
        {
            var campaign = campaignRepository.FindByName(brand);
            if (campaign == null)
            {
                return $"Trying to close an invalid campaign.";
            }

            if (campaign.Budget <= 10000)
            {
                return $"{brand} campaign cannot be closed as it has not met its financial targets.";
            }

            foreach (var contributor in campaign.Contributors)
            {
                var influencer = influencerRepository.FindByName(contributor);
                if (influencer != null)
                {
                    influencer.EarnFee(2000);
                    influencer.EndParticipation(brand);
                }
            }
            campaignRepository.RemoveModel(campaign);

            return $"{brand} campaign has reached its target.";
        }



        public string ConcludeAppContract(string username)
        {
            var influencer = influencerRepository.FindByName(username);
            if (influencer == null)
            {
                return $"{username} has still not signed a contract.";
            }

            if (influencer.Participations.Any())
            {
                return $"{username} cannot conclude the contract while enrolled in active campaigns.";
            }
            influencerRepository.RemoveModel(influencer);

            return $"{username} concluded their contract.";
        }



        public string FundCampaign(string brand, double amount)
        {
            var campaign = campaignRepository.FindByName(brand);
            if (campaign == null)
            {
                return $"Trying to fund an invalid campaign.";
            }

            if (amount <= 0)
            {
                return $"Funding amount must be greater than zero.";
            }

            campaign.Gain(amount);

            return $"{brand} campaign has been successfully funded with {amount} $";
        }



        public string RegisterInfluencer(string typeName, string username, int followers)
        {
            switch (typeName)
            {
                case "BusinessInfluencer":
                    {
                        var influencer = new BusinessInfluencer(username, followers);
                        return AddInfluencerToRepository(influencer);
                    }
                case "FashionInfluencer":
                    {
                        var influencer = new FashionInfluencer(username, followers);
                        return AddInfluencerToRepository(influencer);
                    }
                case "BloggerInfluencer":
                    {
                        var influencer = new BloggerInfluencer(username, followers);
                        return AddInfluencerToRepository(influencer);
                    }
                default:
                    return $"{typeName} has not passed validation.";
            }
        }



        private string AddInfluencerToRepository(IInfluencer influencer)
        {
            if (influencerRepository.Models.Any(i => i.Username == influencer.Username))
            {
                return $"{influencer.Username} is already registered in InfluencerRepository.";
            }
            else
            {
                influencerRepository.AddModel(influencer);
                return $"{influencer.Username} registered successfully to the application.";
            }
        }



        private string AddCampaignToRepository(ICampaign campaign)
        {
            if (campaignRepository.Models.Any(c => c.Brand == campaign.Brand))
            {
                return $"{campaign.Brand} campaign cannot be duplicated.";
            }
            else
            {
                campaignRepository.AddModel(campaign);
                return $"{campaign.Brand} started a {campaign.GetType().Name}.";
            }
        }



        private double CalculateCampaignPrice(ICampaign campaign, IInfluencer influencer)
        {
            double factor = 0.0;
            if (influencer is BusinessInfluencer)
            {
                factor = 0.15;
            }
            else if (influencer is FashionInfluencer)
            {
                factor = 0.1;
            }
            else if (influencer is BloggerInfluencer)
            {
                factor = 0.2;
            }
            else
            {
                throw new ArgumentException("Unknown influencer type");
            }

            double campaignPrice = influencer.Followers * influencer.EngagementRate * factor;

            return Math.Floor(campaignPrice);
        }

    }
}
