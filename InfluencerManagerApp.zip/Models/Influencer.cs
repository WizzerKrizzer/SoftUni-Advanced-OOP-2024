﻿using InfluencerManagerApp.Models.Contracts;
using InfluencerManagerApp.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfluencerManagerApp.Models
{
    public abstract class Influencer : IInfluencer
    {
        private const double Factor = 0.1;
        private string username;
        private int followers;
        private double engagementRate;
        private double income;
        private List<string> participations;

        public Influencer(string username, int followers, double engagementRate)
        {
            this.Username = username;
            this.Followers = followers;
            this.EngagementRate = engagementRate;
            Income = 0.0;
            participations = new List<string>();
        }


        public string Username
        {
            get
            {
                return username;
            }
            private set
            {
                if (String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.UsernameIsRequired);
                }
                this.username = value;
            }
        }


        public int Followers
        {
            get
            {
                return followers;
            }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.FollowersCountNegative);
                }
                this.followers = value;
            }
        }


        public double EngagementRate
        {
            get { return engagementRate; }
            private set { engagementRate = value; }
        }


        public double Income
        {
            get { return income; }
            private set { income = value; }
        }


        public IReadOnlyCollection<string> Participations
        {
            get {return participations.AsReadOnly(); }
        }


        public override string ToString()
        {
            return $"{Username} - Followers: {Followers}, Total Income: {Income}";
        }


        public void EarnFee(double amount)
        {
            Income += amount;
        }

        public void EnrollCampaign(string brand)
        {
            participations.Add(brand);
        }

        public void EndParticipation(string brand)
        {
            participations.Remove(brand);
        }

        public virtual int CalculateCampaignPrice()
        {
            double campaignFee = Followers * EngagementRate * Factor;
            return (int)Math.Floor(campaignFee);
        }
    }
}
