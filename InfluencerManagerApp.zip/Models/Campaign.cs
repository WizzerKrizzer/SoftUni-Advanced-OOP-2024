﻿using InfluencerManagerApp.Models.Contracts;
using InfluencerManagerApp.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfluencerManagerApp.Models
{
    public abstract class Campaign : ICampaign
    {
        private string brand;
        private double budget;
        private List<string> contributors;

        public Campaign(string brand, double budget)
        {
            this.Brand = brand;
            this.Budget = budget;
            contributors = new List<string>();
        }

        public string Brand
        {
            get
            {
                return brand;
            }
            private set
            {
                if (String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.BrandIsrequired);
                }
                this.brand = value;
            }
        }


        public double Budget
        {
            get { return budget; }
            private set { budget = value; }
        }

        public IReadOnlyCollection<string> Contributors
        {
            get { return contributors.AsReadOnly(); }
        }


        public void Engage(IInfluencer influencer)
        {
            throw new NotImplementedException();
        }

        public void Gain(double amount)
        {
            Budget += amount;
        }

        public void Engage(IInfluencer influencer, int campaignPrice)
        {
            if (influencer == null)
            {
                throw new ArgumentNullException(nameof(influencer), "Influencer cannot be null.");
            }

            Budget -= campaignPrice;
            contributors.Add(influencer.Username);
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - Brand: {Brand}, Budget: {Budget}, Contributors: {Contributors.Count}";
        }
    }
}
