using System;
using NUnit.Framework;
using System.Linq;
using System.Collections.Generic;

namespace SocialMediaManager.Tests
{
    public class InfluencerRepositoryTests
    {
        private InfluencerRepository influencerRepository;

        [SetUp]
        public void Setup()
        {
            influencerRepository = new InfluencerRepository();
        }

        [Test]
        public void RegisterInfluencer_Success()
        {
            // Arrange
            var influencer = new Influencer("testUser", 1000);

            // Act
            var result = influencerRepository.RegisterInfluencer(influencer);

            // Assert
            Assert.AreEqual($"Successfully added influencer {influencer.Username} with {influencer.Followers}", result);
            Assert.IsTrue(influencerRepository.Influencers.Contains(influencer));
        }

        [Test]
        public void RegisterInfluencer_NullInfluencer_ThrowsArgumentNullException()
        {
            // Arrange, Act & Assert
            Assert.Throws<ArgumentNullException>(() => influencerRepository.RegisterInfluencer(null));
        }

        [Test]
        public void RegisterInfluencer_DuplicateUsername_ThrowsInvalidOperationException()
        {
            // Arrange
            var influencer1 = new Influencer("testUser", 1000);
            var influencer2 = new Influencer("testUser", 2000);
            influencerRepository.RegisterInfluencer(influencer1);

            // Act & Assert
            Assert.Throws<InvalidOperationException>(() => influencerRepository.RegisterInfluencer(influencer2));
        }

        [Test]
        public void RemoveInfluencer_Success()
        {
            // Arrange
            var influencer = new Influencer("testUser", 1000);
            influencerRepository.RegisterInfluencer(influencer);

            // Act
            var result = influencerRepository.RemoveInfluencer("testUser");

            // Assert
            Assert.IsTrue(result);
            Assert.IsFalse(influencerRepository.Influencers.Contains(influencer));
        }

        [Test]
        public void RemoveInfluencer_NullOrEmptyUsername_ThrowsArgumentNullException()
        {
            // Arrange, Act & Assert
            Assert.Throws<ArgumentNullException>(() => influencerRepository.RemoveInfluencer(null));
            Assert.Throws<ArgumentNullException>(() => influencerRepository.RemoveInfluencer(""));
            Assert.Throws<ArgumentNullException>(() => influencerRepository.RemoveInfluencer("   "));
        }

        [Test]
        public void GetInfluencerWithMostFollowers_Success()
        {
            // Arrange
            var influencer1 = new Influencer("user1", 1000);
            var influencer2 = new Influencer("user2", 2000);
            var influencer3 = new Influencer("user3", 500);
            influencerRepository.RegisterInfluencer(influencer1);
            influencerRepository.RegisterInfluencer(influencer2);
            influencerRepository.RegisterInfluencer(influencer3);

            // Act
            var result = influencerRepository.GetInfluencerWithMostFollowers();

            // Assert
            Assert.AreEqual(influencer2, result);
        }

        [Test]
        public void GetInfluencer_Success()
        {
            // Arrange
            var influencer = new Influencer("testUser", 1000);
            influencerRepository.RegisterInfluencer(influencer);

            // Act
            var result = influencerRepository.GetInfluencer("testUser");

            // Assert
            Assert.AreEqual(influencer, result);
        }
    }
}
