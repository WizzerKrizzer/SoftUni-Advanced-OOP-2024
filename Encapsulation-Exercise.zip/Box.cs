﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassBoxData
{
    public class Box
    {
        private double length;
        private double width;
        private double height;
        private double surfaceAreaMath;
        private double lateralSurfaceAreaMath;
        private double volumeMath;

        public Box(double length, double width, double height)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }

        public double Length
        {
            get
            {
                return length;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException($"Length cannot be zero or negative.");
                }
                length = value;
            }
        }
        public double Width
        {
            get
            {
                return width;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException($"Width cannot be zero or negative.");
                }
                width = value;
            }
        }
        public double Height
        {
            get
            {
                return height;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException($"Height cannot be zero or negative.");
                }
                height = value;
            }
        }
        public double SurfaceAreaMath
        {
            get
            {
                return 2 * Length * Width + 2 * Length * Height + 2 * Width * Height;
            }
            private set
            {
                surfaceAreaMath = value;
            }
        }
        public double LateralSurfaceAreaMath
        {
            get
            {
                return 2 * Length * Height + 2 * Width * Height;
            }
            private set
            {
                lateralSurfaceAreaMath = value;
            }
        }
        public double VolumeMath
        {
            get
            {
                return Length * Width * Height;
            }
            private set
            {
                volumeMath = value;
            }
        }
    }
}
