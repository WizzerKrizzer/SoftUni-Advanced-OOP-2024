﻿namespace ClassBoxData
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            try
            {
                double length = double.Parse(Console.ReadLine());
                double width = double.Parse(Console.ReadLine());
                double height = double.Parse(Console.ReadLine());
                Box box = new Box(length, width, height);
                Console.WriteLine($"Surface Area - {box.SurfaceAreaMath:f2}\nLateral Surface Area - {box.LateralSurfaceAreaMath:f2}\nVolume - {box.VolumeMath:f2}");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }        
        }
    }
}